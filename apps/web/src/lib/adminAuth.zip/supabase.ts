// apps/web/src/lib/supabase.ts
// Tiny Supabase-like client for your Mongo adapter + a DEV auth shim compatible with your AuthContext.

export type Query = Record<string, unknown>;
export type Sort = Record<string, 1 | -1>;

export interface SelectOptions {
  q?: Query | null;
  limit?: number;
  skip?: number;
  sort?: Sort | null;
}

export type Result<Data> =
  | { data: Data; error: null }
  | { data: null; error: unknown };

export interface SupabaseLikeTable<T> {
  select(options?: SelectOptions): Promise<Result<T[]>>;
  insert(rows: T | T[]): Promise<Result<T | T[]>>;
  update(patch: Partial<T>, id: string): Promise<Result<T>>;
  delete(id: string): Promise<Result<null>>;
}

export interface SupabaseLikeClient {
  from<T = unknown>(table: string): SupabaseLikeTable<T>;
}

function getBaseUrl() {
  return (
    (typeof process !== "undefined" &&
      (process.env.NEXT_PUBLIC_API_URL || process.env.VITE_API_URL)) ||
    "http://localhost:8000"
  ).replace(/\/$/, "");
}

export function createClient(baseUrl: string): SupabaseLikeClient {
  const base = baseUrl.replace(/\/$/, "");
  const headers = (): HeadersInit => ({ "Content-Type": "application/json" });

  return {
    from<T = unknown>(table: string): SupabaseLikeTable<T> {
      const url = `${base}/api/${table}`;

      return {
        async select(options: SelectOptions = {}): Promise<Result<T[]>> {
          const { q = null, limit = 50, skip = 0, sort = null } = options;
          const params = new URLSearchParams();
          if (q) params.set("q", JSON.stringify(q));
          if (sort) params.set("sort", JSON.stringify(sort));
          if (typeof limit === "number") params.set("limit", String(limit));
          if (typeof skip === "number") params.set("skip", String(skip));

          const res = await fetch(`${url}?${params.toString()}`);
          const data = (await res.json().catch(() => null)) as unknown;
          if (!res.ok) return { data: null, error: data };
          return { data: data as T[], error: null };
        },

        async insert(rows: T | T[]): Promise<Result<T | T[]>> {
          const res = await fetch(url, {
            method: "POST",
            headers: headers(),
            body: JSON.stringify(rows),
          });
          const data = (await res.json().catch(() => null)) as unknown;
          if (!res.ok) return { data: null, error: data };
          return { data: data as T | T[], error: null };
        },

        async update(patch: Partial<T>, id: string): Promise<Result<T>> {
          const res = await fetch(`${url}/${id}`, {
            method: "PATCH",
            headers: headers(),
            body: JSON.stringify(patch),
          });
          const data = (await res.json().catch(() => null)) as unknown;
          if (!res.ok) return { data: null, error: data };
          return { data: data as T, error: null };
        },

        async delete(id: string): Promise<Result<null>> {
          const res = await fetch(`${url}/${id}`, { method: "DELETE" });
          if (!res.ok) return { data: null, error: await res.text() };
          return { data: null, error: null };
        },
      };
    },
  };
}

/* --------------------------- DEV Auth Compatibility --------------------------- */
/* Matches your AuthContext usage:
   - getSession(): Promise<Session | null>
   - onAuthStateChange((event, session) => void)
   - signIn(email, password), signUp(email, password, metadata)
   - signOut(), resetPassword(email), updatePassword(password)
*/

type AuthUser = {
  id: string;
  email: string;
  created_at: string;
  updated_at: string;
  email_confirmed_at: string | null;
  last_sign_in_at: string | null;
  [k: string]: unknown;
};

type AuthSession = {
  access_token: string;
  token_type: "bearer";
  user: AuthUser;
} | null;

const LS_USER_KEY = "mm_user";
const LS_SESSION_KEY = "mm_session";

const hasStorage =
  typeof window !== "undefined" && typeof window.localStorage !== "undefined";

function load<T>(key: string): T | null {
  if (!hasStorage) return null;
  try {
    const v = localStorage.getItem(key);
    return v ? (JSON.parse(v) as T) : null;
  } catch {
    return null;
  }
}
function save(key: string, val: unknown) {
  if (hasStorage) localStorage.setItem(key, JSON.stringify(val));
}
function clearKey(key: string) {
  if (hasStorage) localStorage.removeItem(key);
}
function nowISO() {
  return new Date().toISOString();
}
function uuid() {
  try {
    // @ts-ignore
    if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID();
  } catch {}
  return "id-" + Math.random().toString(36).slice(2);
}

// Simple event bus
type AuthEvent =
  | "SIGNED_IN"
  | "SIGNED_OUT"
  | "TOKEN_REFRESHED"
  | "USER_UPDATED"
  | "PASSWORD_RECOVERY"
  | "TOKEN_CHANGED";

const subscribers = new Set<(event: AuthEvent, session: AuthSession) => void>();
function notify(event: AuthEvent, session: AuthSession) {
  subscribers.forEach((cb) => cb(event, session));
}

export const auth = {
  /* Your AuthContext calls getSession() and expects Session | null */
  async getSession(): Promise<AuthSession> {
    return load<AuthSession>(LS_SESSION_KEY);
  },

  /* Your AuthContext subscribes and expects (event, session) */
  onAuthStateChange(
    callback: (event: AuthEvent, session: AuthSession) => void
  ) {
    subscribers.add(callback);
    // Immediately send current session so UI can render
    callback("TOKEN_CHANGED", load<AuthSession>(LS_SESSION_KEY));
    return {
      data: {
        subscription: {
          unsubscribe() {
            subscribers.delete(callback);
          },
        },
      },
      error: null as unknown,
    };
  },

  /* Your AuthContext calls auth.signIn(email, password) */
  async signIn(email: string, password?: string) {
    if (!email) throw new Error("Invalid email");
    // DEV: accept any password; mark email as confirmed so your guard passes
    const existing = load<AuthUser>(LS_USER_KEY);
    const user: AuthUser =
      existing && existing.email === email
        ? { ...existing, last_sign_in_at: nowISO() }
        : {
            id: uuid(),
            email,
            created_at: nowISO(),
            updated_at: nowISO(),
            email_confirmed_at: nowISO(), // important for your AuthContext
            last_sign_in_at: nowISO(),
          };
    save(LS_USER_KEY, user);

    const session: NonNullable<AuthSession> = {
      access_token: "dev-token",
      token_type: "bearer",
      user,
    };
    save(LS_SESSION_KEY, session);
    notify("SIGNED_IN", session);
    return { user, session };
  },

  /* Your AuthContext calls auth.signUp(email, password, metadata) */
  async signUp(email: string, _password: string, metadata?: Record<string, unknown>) {
    if (!email) throw new Error("Invalid email");
    const user: AuthUser = {
      id: uuid(),
      email,
      created_at: nowISO(),
      updated_at: nowISO(),
      email_confirmed_at: nowISO(), // auto-confirm in DEV
      last_sign_in_at: null,
      ...(metadata ?? {}),
    };
    save(LS_USER_KEY, user);
    const session: NonNullable<AuthSession> = {
      access_token: "dev-token",
      token_type: "bearer",
      user,
    };
    save(LS_SESSION_KEY, session);
    notify("SIGNED_IN", session);
    return { user, session };
  },

  async signOut() {
    clearKey(LS_SESSION_KEY);
    notify("SIGNED_OUT", null);
    return { error: null as unknown };
  },

  async resetPassword(_email: string) {
    // DEV no-op
    return { data: true, error: null as unknown };
  },

  async updatePassword(_password: string) {
    // DEV no-op
    return { data: true, error: null as unknown };
  },
};

/* ------------------------------- Data Client ------------------------------- */

const BASE_URL = getBaseUrl();
export const supabase = createClient(BASE_URL);

// Minimal `db` facade matching your calls in AuthContext
export const db = {
  profiles: {
    async getById<T = any>(id: string): Promise<T | null> {
      const res = await fetch(`${BASE_URL}/api/profiles/${encodeURIComponent(id)}`);
      if (res.status === 404) return null;
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as T;
    },
    async update<T = any>(id: string, patch: Partial<T>): Promise<T> {
      const res = await fetch(`${BASE_URL}/api/profiles/${encodeURIComponent(id)}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(patch),
      });
      if (!res.ok) throw new Error(await res.text());
      return (await res.json()) as T;
    },
  },
};

// Optional: allow code using `supabase.auth`
/* eslint-disable @typescript-eslint/no-explicit-any */
(supabase as any).auth = auth;
/* eslint-enable @typescript-eslint/no-explicit-any */

export default supabase;
