import axios from "axios";

function getBaseUrl() {
  const url =
    (typeof import.meta !== "undefined" &&
      (import.meta as any)?.env?.VITE_API_URL) ||
    (typeof process !== "undefined"
      ? (process as any)?.env?.VITE_API_URL ||
        (process as any)?.env?.NEXT_PUBLIC_API_URL
      : "") ||
    "http://localhost:8000";
  return (url || "http://localhost:8000").replace(/\/$/, "");
}

const api = axios.create({
  baseURL: getBaseUrl(),
  headers: { "Content-Type": "application/json" },
});

export async function bookSession(payload: {
  student_id: string;
  tutor_id: string;
  subject_id?: string;
  starts_at: string | Date;
  ends_at: string | Date;
  notes?: string;
}) {
  const res = await api.post("/api/session_bookings", payload);
  return res.data?.data;
}

export async function listSessions(filter: any = {}, limit = 100) {
  const res = await api.get("/api/session_bookings", {
    params: {
      q: JSON.stringify(filter),
      sort: JSON.stringify({ createdAt: -1 }),
      limit,
    },
  });
  return res.data?.data ?? [];
}
